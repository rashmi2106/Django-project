from django.urls import path,include
from . import views
urlpatterns = [
    path('',views.home),
    path('addstudent',views.addstudent),
    path('showstudents',views.showstudents),
    path('updatestudent',views.updatestudent),
    path('searchstudent',views.searchstudent),
    path('joinstudent',views.joinstudent),
    path('showjoinedstudent',views.showjoined),
    path('updatejoined',views.updatejoined),
    path('searchjoined',views.searchjoined),
    path('addbatches',views.addbatches),
    path('showbatches',views.showbatches),
    path('updatebatches',views.updatebatches),
    path('deletebatches',views.deletebatches),
    path('searchbatches',views.searchbatches),
    path('addtrainer',views.addtrainer),
    path('showtrainer',views.showtrainer),
    path('updatetrainer',views.updatetrainer),
    path('deletetrainer',views.deletetrainer),
    path('searchtrainer',views.searchtrainer),
]