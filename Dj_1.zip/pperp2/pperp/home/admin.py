from django.contrib import admin
from .models import Student,Joined,Batch,Trainer
admin.site.register(Student)
admin.site.register(Joined)
admin.site.register(Batch)
admin.site.register(Trainer)
# Register your models here.
